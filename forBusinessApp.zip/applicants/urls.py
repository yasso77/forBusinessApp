from os import path


urlpatterns = [
   
]